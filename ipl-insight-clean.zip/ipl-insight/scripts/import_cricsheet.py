import json
import os
import glob
import psycopg2
from datetime import datetime

# Database connection parameters
DB_NAME = "ipl_insight"
DB_HOST = "localhost" 
DATA_DIR = "../data" # Points to the folder we just created

def get_db_connection():
    # Connects to the local PostgreSQL database
    return psycopg2.connect(dbname=DB_NAME, host=DB_HOST)

def insert_dimension_data(cursor, data):
    """Inserts seasons, teams, and players and returns their database IDs."""
    info = data.get('info', {})
    
    # 1. Season
    dates = info.get('dates', [])
    match_date = dates[0] if dates else '2008-01-01'
    year = int(str(info.get('season', match_date[:4]))[:4])
    
    cursor.execute(
        "INSERT INTO seasons (year) VALUES (%s) ON CONFLICT (year) DO UPDATE SET year=EXCLUDED.year RETURNING id;",
        (year,)
    )
    season_id = cursor.fetchone()[0]

    # 2. Teams
    teams = info.get('teams', [])
    team_ids = {}
    for team in teams:
        cursor.execute(
            "INSERT INTO teams (name) VALUES (%s) ON CONFLICT (name) DO UPDATE SET name=EXCLUDED.name RETURNING id;",
            (team,)
        )
        team_ids[team] = cursor.fetchone()[0]

    # 3. Players (Mapping Registry to IDs)
    registry = info.get('registry', {}).get('people', {})
    player_ids = {}
    for player_name, cricsheet_id in registry.items():
        cursor.execute(
            """
            INSERT INTO players (cricsheet_id, name) 
            VALUES (%s, %s) 
            ON CONFLICT (cricsheet_id) DO UPDATE SET name=EXCLUDED.name 
            RETURNING id;
            """,
            (cricsheet_id, player_name)
        )
        player_ids[player_name] = cursor.fetchone()[0]

    return season_id, team_ids, player_ids

def import_match(filepath, conn):
    """Parses a JSON file and inserts match and ball-by-ball delivery data."""
    filename = os.path.basename(filepath)
    if not filename.endswith('.json'):
        return
    
    cricsheet_match_id = int(filename.split('.')[0])
    
    with open(filepath, 'r') as file:
        data = json.load(file)
        
    info = data.get('info', {})
    cursor = conn.cursor()

    try:
        # Check if match already exists to avoid duplicates
        cursor.execute("SELECT id FROM matches WHERE cricsheet_match_id = %s;", (cricsheet_match_id,))
        if cursor.fetchone():
            return

        # Insert dimensions
        season_id, team_ids, player_ids = insert_dimension_data(cursor, data)

        # Parse Match Info
        dates = info.get('dates', [])
        match_date = datetime.strptime(dates[0], '%Y-%m-%d').date() if dates else None
        venue = info.get('venue')
        city = info.get('city')
        teams = info.get('teams', [])
        
        toss = info.get('toss', {})
        toss_winner = toss.get('winner')
        toss_decision = toss.get('decision')
        
        outcome = info.get('outcome', {})
        winner = outcome.get('winner')
        result = outcome.get('result', 'completed')
        result_margin = outcome.get('by', {}).get('runs') or outcome.get('by', {}).get('wickets')
        
        pom_list = info.get('player_of_match', [])
        player_of_match = pom_list[0] if pom_list else None

        # Insert Match
        cursor.execute(
            """
            INSERT INTO matches 
            (cricsheet_match_id, season_id, date, venue, city, team1_id, team2_id, 
            toss_winner_id, toss_decision, winner_id, result, result_margin, player_of_match_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id;
            """,
            (
                cricsheet_match_id, season_id, match_date, venue, city,
                team_ids.get(teams[0]) if len(teams) > 0 else None,
                team_ids.get(teams[1]) if len(teams) > 1 else None,
                team_ids.get(toss_winner), toss_decision,
                team_ids.get(winner), result, result_margin,
                player_ids.get(player_of_match)
            )
        )
        match_pk = cursor.fetchone()[0]

        # Insert Deliveries
        for inn_idx, inning in enumerate(data.get('innings', [])):
            batting_team = inning.get('team')
            bowling_team = teams[1] if batting_team == teams[0] else teams[0]
            
            for over in inning.get('overs', []):
                over_no = over.get('over')
                for ball_idx, delivery in enumerate(over.get('deliveries', [])):
                    
                    runs = delivery.get('runs', {})
                    extras = delivery.get('extras', {})
                    wickets = delivery.get('wickets', [])
                    
                    is_wicket = len(wickets) > 0
                    dismissal_kind = wickets[0].get('kind') if is_wicket else None
                    player_out = wickets[0].get('player_out') if is_wicket else None
                    fielder = None
                    if is_wicket and 'fielders' in wickets[0] and len(wickets[0]['fielders']) > 0:
                        fielder = wickets[0]['fielders'][0].get('name')

                    cursor.execute(
                        """
                        INSERT INTO deliveries 
                        (match_id, inning, over_no, ball_no, batting_team_id, bowling_team_id,
                        batter_id, bowler_id, non_striker_id, batter_runs, extra_runs, total_runs,
                        is_wide, is_noball, is_legbye, is_bye, is_wicket, dismissal_kind, player_out_id, fielder_id)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                        """,
                        (
                            match_pk, inn_idx + 1, over_no, ball_idx + 1,
                            team_ids.get(batting_team), team_ids.get(bowling_team),
                            player_ids.get(delivery.get('batter')),
                            player_ids.get(delivery.get('bowler')),
                            player_ids.get(delivery.get('non_striker')),
                            runs.get('batter', 0), runs.get('extras', 0), runs.get('total', 0),
                            'wides' in extras, 'noballs' in extras, 'legbyes' in extras, 'byes' in extras,
                            is_wicket, dismissal_kind,
                            player_ids.get(player_out), player_ids.get(fielder)
                        )
                    )
        conn.commit()
        print(f"Successfully imported match: {cricsheet_match_id}")

    except Exception as e:
        conn.rollback()
        print(f"Error importing match {cricsheet_match_id}: {e}")

def run_import():
    conn = get_db_connection()
    json_files = glob.glob(os.path.join(DATA_DIR, "*.json"))
    total_files = len(json_files)
    
    if total_files == 0:
        print(f"No JSON files found in {DATA_DIR}. Please check the extraction path.")
        return
        
    print(f"Found {total_files} match files. Starting import...")
    
    for idx, filepath in enumerate(json_files, 1):
        print(f"Processing {idx}/{total_files}...", end=" ")
        import_match(filepath, conn)
        
    conn.close()
    print("Data import complete!")

if __name__ == "__main__":
    run_import()